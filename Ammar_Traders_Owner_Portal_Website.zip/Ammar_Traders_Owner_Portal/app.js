/* Ammar Wholesale Shop owner-dashboard demo, created for Al Digital Technology.
 * All table data is fictional and ships in demo-data.js.
 * Live AI chat requires a working n8n Chat Trigger + an authenticated owner backend.
 * A webhook URL embedded in JavaScript is NOT a secret, and this static site is NOT an access control system.
 */
(() => {
'use strict';
const WEBHOOK_URL = 'https://abdullahagent1.app.n8n.cloud/webhook/237e0180-34f4-4f94-bbf1-a0fa5d92d980/chat';
const SNAPSHOT = '2026-10-26';
const D = window.AMMAR_DEMO_DATA || {};
const products=D.Products||[], retailers=D.Retailers||[], orders=D.Orders||[], deliveries=D.Deliveries||[], offers=D.Offers||[], comps=D.CompetitorPrices||[];
const $=id=>document.getElementById(id);
const fmt = n => Number(n||0).toLocaleString('en-PK',{maximumFractionDigits:0});
const money = n => 'Rs ' + fmt(n);
const esc = s => String(s==null?'':s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const icons = id => `<svg aria-hidden="true"><use href="#i-${id}"></use></svg>`;
const status = value => { const v=String(value||'').toUpperCase(); const color=({PAID:'success',DELIVERED:'success',RECEIVED:'success',ACTIVE:'success',CONFIRMED:'info',DISPATCHED:'info',PACKED:'warn',PENDING:'warn',PARTIAL:'warn',UNPAID:'danger',OVERDUE:'danger',LOW_STOCK:'danger',DRAFT:'neutral'})[v]||'neutral'; return `<span class="status ${color}">${esc(v.replaceAll('_',' '))}</span>`; };
const datestr= s=>{if(!s)return '—';const a=String(s).slice(0,10).split('-');return a.length===3?`${a[2]} ${['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'][+a[1]-1]} ${a[0]}`:esc(s)};
const ordered=orders.slice().sort((a,b)=>String(b.order_date+' '+b.order_id).localeCompare(String(a.order_date+' '+a.order_id)));
const unpaid=orders.filter(o=>+o.balance>0.01).sort((a,b)=>String(a.due_date).localeCompare(String(b.due_date)));
const overdue=unpaid.filter(o=>o.due_date && o.due_date<SNAPSHOT);
const salesOnDate=orders.filter(o=>o.order_date===SNAPSHOT);
const salesTotal=salesOnDate.reduce((t,o)=>t+Number(o.total||0),0);
const outstanding=unpaid.reduce((t,o)=>t+Number(o.balance||0),0);
const todayPaid=salesOnDate.reduce((t,o)=>t+Number(o.paid||0),0);
const stockLow=products.filter(p=>+p.stock_qty<=+p.reorder_level);
let activeView='dashboard';let liveMode=false;let sending=false;
let sessionId= (globalThis.crypto && crypto.randomUUID) ? crypto.randomUUID() : 'ammar-'+Date.now()+'-'+Math.random().toString(36).slice(2);
let toastTimer;
const COMMANDS=[
  ['Aaj ki sales',`2026-10-26 ko kitni sales hui aur kitne orders aaye?`],
  ['Udhaar list','Kin shops ki overdue payment hai? Har shop ka baqi balance batao.'],
  ['Delivery update','Kaun se orders abhi pending aur dispatched hain?'],
  ['Low-stock products','Kaun se products reorder karne hain?'],
  ['New discount offer','MAKEUP category ke liye discount offer ka email draft banwana hai. Mujhse rate aur timing confirm karo, send mat karna.'],
  ['Market rate comparison','Lipstick ki wholesale price aur market rate compare karo. Sirf verified competitor prices do; sample data ko demo batao.']
];
function announce(text){const t=$('toast');t.textContent=text;t.classList.add('show');clearTimeout(toastTimer);toastTimer=setTimeout(()=>t.classList.remove('show'),3600)}
function navigate(view){
 if(!$('view-'+view))return;activeView=view;
 document.querySelectorAll('.view').forEach(el=>el.classList.toggle('active',el.id==='view-'+view));
 document.querySelectorAll('.nav-link').forEach(el=>{el.classList.toggle('active',el.dataset.view===view);el.setAttribute('aria-current',el.dataset.view===view?'page':'false')});
 const labels={dashboard:'Overview',boss:'AI Business Boss',orders:'Orders',inventory:'Inventory',payments:'Payments & Udhaar',deliveries:'Deliveries',offers:'Offers & Email',reports:'Reports',settings:'Settings & Setup'};
 $('breadName').textContent=labels[view]||'Workspace';
 $('sidebar').classList.remove('open');$('sidebarMask').hidden=true;
 window.scrollTo({top:0,behavior:'instant'});
 if(view==='boss'){setTimeout(()=>$('chatInput').focus({preventScroll:true}),80)}
}
function miniStats(id,blocks){$(id).innerHTML=blocks.map(b=>`<div class="mini-stat"><label>${esc(b.title)}</label><strong>${esc(b.value)}</strong><small>${esc(b.note)}</small></div>`).join('')}
function table(headers,rows,emptyText='No matching records found'){
 if(!rows.length)return `<div class="table-empty">${esc(emptyText)}</div>`;
 return `<table><thead><tr>${headers.map(h=>`<th>${esc(h)}</th>`).join('')}</tr></thead><tbody>${rows.join('')}</tbody></table>`;
}
function stat(icon,cls,title,value,note){return `<article class="stat-card"><div class="stat-top"><span class="stat-label">${esc(title)}</span><span class="stat-icon ${cls}">${icons(icon)}</span></div><div class="stat-value">${esc(value)}</div><div class="stat-bottom">${esc(note)}</div></article>`}
function drawChart(id){
 const dataset=[];
 for(let i=6;i>=0;i--){const dt=new Date(SNAPSHOT+'T12:00:00');dt.setDate(dt.getDate()-i);const date=[dt.getFullYear(),String(dt.getMonth()+1).padStart(2,'0'),String(dt.getDate()).padStart(2,'0')].join('-');dataset.push({date,label:String(dt.getDate()).padStart(2,'0')+' Oct',value:orders.filter(o=>o.order_date===date).reduce((a,o)=>a+Number(o.total),0)})}
 const w=650,h=222,top=15,bottom=35,left=44,right=15;const max=Math.max(...dataset.map(d=>d.value),1);const ceil=Math.ceil(max/5000)*5000||5000;const x=i=>left+(w-left-right)*i/6;const y=v=>top+(h-top-bottom)*(1-v/ceil);
 const dots=dataset.map((d,i)=>[x(i),y(d.value)]);const path=dots.map((p,i)=>(i?'L':'M')+p.map(n=>n.toFixed(1)).join(' ')).join(' ');
 let svg=`<svg viewBox="0 0 ${w} ${h}" role="img" aria-label="Demo sales chart for last 7 days from 26 October 2026">`;
 for(let j=0;j<=3;j++){const v=ceil*j/3,yy=y(v);svg+=`<line class="chart-grid" x1="${left}" y1="${yy}" x2="${w-right}" y2="${yy}"/><text x="${left-9}" y="${yy+4}" text-anchor="end">${v>=1000?Math.round(v/1000)+'k':fmt(v)}</text>`}
 svg+=`<path class="chart-area" d="${path} L${x(6)} ${y(0)} L${x(0)} ${y(0)} Z"/>`;
 svg+=`<path class="chart-line" d="${path}"/>`;
 dots.forEach((p,i)=>svg+=`<circle class="chart-dot" cx="${p[0]}" cy="${p[1]}" r="4"><title>${dataset[i].date}: ${money(dataset[i].value)}</title></circle>`);
 dataset.forEach((d,i)=>svg+=`<text text-anchor="middle" x="${x(i)}" y="${h-8}">${d.label}</text>`);
 svg+='</svg>';
 $(id).innerHTML=svg;
}
function drawDashboard(){
 $('statsGrid').innerHTML=stat('chart','green','Demo sales · 26 Oct',money(salesTotal),`${salesOnDate.length} invoiced orders`)+stat('orders','orange','Total orders',fmt(orders.length),'All sample orders')+stat('wallet','rose','Unpaid balances',money(outstanding),`${overdue.length} overdue as of 26 Oct`)+stat('box','blue','Active products',fmt(products.length),`${stockLow.length} at or below reorder level`);
 drawChart('salesChart');
 $('recentOrders').innerHTML=table(['ORDER','SHOP','AMOUNT','STATUS'],ordered.slice(0,5).map(o=>`<tr><td><strong>${esc(o.order_id)}</strong><small>${datestr(o.order_date)}</small></td><td>${esc(o.shop_name)}</td><td><strong>${money(o.total)}</strong></td><td>${status(o.order_status)}</td></tr>`));
 const counts={PENDING:0,DISPATCHED:0,DELIVERED:0};deliveries.forEach(d=>{if(d.status in counts)counts[d.status]++});const max=deliveries.length||1;
 $('deliveryWidget').innerHTML=`<div class="delivery-widget">${Object.entries(counts).map(([k,v])=>`<div class="delivery-row"><div class="delivery-name"><span>${k.charAt(0)+k.slice(1).toLowerCase()}</span><strong>${v} orders</strong></div><div class="bar"><span class="${k==='PENDING'?'bar-warning':k==='DISPATCHED'?'bar-info':''}" style="width:${(v/max*100).toFixed(1)}%"></span></div></div>`).join('')}<p class="delivery-help">Delivery figures are from fictional sample records. Confirm live statuses with the AI Boss only after backend setup.</p></div>`;
}
function renderOrders(){const q=$('orderSearch').value.trim().toLowerCase(),f=$('orderFilter').value;const matches=ordered.filter(o=>(f==='all'||o.order_status===f)&&`${o.order_id} ${o.shop_name} ${o.retailer_id}`.toLowerCase().includes(q));
 $('orderTable').innerHTML=table(['ORDER ID','RETAILER','DATE','TOTAL','PAID','PAYMENT','STATUS'],matches.map(o=>`<tr><td><strong>${esc(o.order_id)}</strong></td><td><strong>${esc(o.shop_name)}</strong><small>${esc(o.retailer_id)}</small></td><td>${datestr(o.order_date)}</td><td><strong>${money(o.total)}</strong></td><td>${money(o.paid)}</td><td>${status(o.payment_status)}</td><td>${status(o.order_status)}</td></tr>`));}
function renderInventory(){const q=$('inventorySearch').value.toLowerCase().trim(),f=$('inventoryFilter').value;const matches=products.filter(p=>(f==='all'||p.category===f)&&`${p.product_name} ${p.product_id} ${p.category}`.toLowerCase().includes(q));$('inventoryTable').innerHTML=table(['PRODUCT','CATEGORY','WHOLESALE','IN STOCK','REORDER AT','STOCK STATUS'],matches.map(p=>`<tr><td><strong>${esc(p.product_name)}</strong><small>${esc(p.product_id)}</small></td><td>${esc(({COS:'Cosmetics',SKIN:'Skincare',MAKEUP:'Makeup',HAIR:'Haircare',ACCESS:'Accessories'})[p.category]||p.category)}</td><td><strong>${money(p.wholesale_price)}</strong></td><td>${fmt(p.stock_qty)}</td><td>${fmt(p.reorder_level)}</td><td>${status(+p.stock_qty<=+p.reorder_level?'LOW_STOCK':'ACTIVE')}</td></tr>`));}
function renderPayments(){const q=$('paymentSearch').value.toLowerCase().trim();const matches=unpaid.filter(o=>`${o.shop_name} ${o.order_id}`.toLowerCase().includes(q));$('paymentTable').innerHTML=table(['RETAILER','ORDER ID','TOTAL','AMOUNT DUE','DUE DATE','STATUS'],matches.map(o=>`<tr><td><strong>${esc(o.shop_name)}</strong></td><td>${esc(o.order_id)}</td><td>${money(o.total)}</td><td><strong>${money(o.balance)}</strong></td><td>${datestr(o.due_date)}</td><td>${status(o.due_date<SNAPSHOT?'OVERDUE':o.payment_status)}</td></tr>`));}
function renderDeliveries(){const f=$('deliveryFilter').value;const matches=deliveries.filter(d=>f==='all'||d.status===f).slice().sort((a,b)=>String(b.order_id).localeCompare(String(a.order_id)));$('deliveryTable').innerHTML=table(['DELIVERY ID','RETAILER','AREA','ORDER','ASSIGNED TO','STATUS'],matches.map(d=>`<tr><td><strong>${esc(d.delivery_id)}</strong></td><td>${esc(d.shop_name)}</td><td>${esc(d.area)}</td><td>${esc(d.order_id)}</td><td>${esc(d.driver||'Not assigned')}</td><td>${status(d.status)}</td></tr>`));}
function renderOffers(){$('offerTable').innerHTML=table(['OFFER','CATEGORY','DISCOUNT','START','END','STATUS'],offers.map(o=>`<tr><td><strong>${esc(o.title)}</strong></td><td>${esc(o.category)}</td><td>${esc(o.discount_pct)}%</td><td>${esc(o.start_at)}</td><td>${esc(o.end_at)}</td><td>${status(o.status)}</td></tr>`));}
function setupStats(){miniStats('orderMiniStats',[{title:'Total orders',value:fmt(orders.length),note:'Demo orders'},{title:'Invoiced on 26 Oct',value:salesOnDate.length, note:money(salesTotal)},{title:'Orders not delivered',value:fmt(orders.filter(o=>o.order_status!=='DELIVERED').length),note:'Based on order status'}]);
miniStats('inventoryMiniStats',[{title:'Catalog products',value:fmt(products.length),note:'Demo items'},{title:'Low stock alerts',value:fmt(stockLow.length),note:'At/below reorder level'},{title:'Stock units available',value:fmt(products.reduce((t,p)=>t+ +p.stock_qty,0)),note:'Demo total'}]);
miniStats('paymentMiniStats',[{title:'Total outstanding',value:money(outstanding),note:'Sample unpaid invoices'},{title:'Overdue invoices',value:fmt(overdue.length),note:'As of 26 Oct 2026'},{title:'Paid on snapshot date',value:money(todayPaid),note:'On 26 Oct orders'}]);
miniStats('deliveryMiniStats',[{title:'Waiting dispatch',value:fmt(deliveries.filter(d=>d.status==='PENDING').length),note:'Demo pending'},{title:'On the way',value:fmt(deliveries.filter(d=>d.status==='DISPATCHED').length),note:'Demo dispatched'},{title:'Delivered',value:fmt(deliveries.filter(d=>d.status==='DELIVERED').length),note:'Demo complete'}]);
miniStats('reportsMiniStats',[{title:'Total invoiced',value:money(orders.reduce((t,o)=>t+ +o.total,0)),note:'All sample orders'},{title:'Collected payments',value:money(orders.reduce((t,o)=>t+ +o.paid,0)),note:'From sample orders'},{title:'Pending collection',value:money(outstanding),note:'Sample balances'}]);}
function initOrderDialog(){const shops=$('newShop'),pr=$('newProduct');shops.innerHTML=retailers.map(r=>`<option value="${esc(r.retailer_id)}">${esc(r.shop_name)} (${esc(r.retailer_id)})</option>`).join('');pr.innerHTML=products.map(p=>`<option value="${esc(p.product_id)}">${esc(p.product_name)} — ${money(p.wholesale_price)}</option>`).join('');
 const update=()=>{const p=products.find(p=>p.product_id===pr.value);const qty=Number($('newQty').value),disc=Number($('newDiscount').value);if(!p||!Number.isInteger(qty)||qty<1||!Number.isFinite(disc)||disc<0||disc>50){$('quotePreview').textContent='Enter a valid quantity and discount.';$('prepareOrder').disabled=true;return;}$('prepareOrder').disabled=false;const sum=qty*p.wholesale_price;const total=sum*(1-disc/100);$('quotePreview').innerHTML=`Estimated quotation: <strong>${money(total)}</strong> <br> ${qty} × ${money(p.wholesale_price)} less ${disc}% discount. <br> <small>Stock shown: ${fmt(p.stock_qty)} units · not reserved</small>`;};
 ['newShop','newProduct','newQty','newDiscount'].forEach(id=>$(id).addEventListener('input',update));update();
 $('newOrder').addEventListener('click',()=>{$('orderDialog').showModal();update()});
 $('closeDialog').addEventListener('click',()=>$('orderDialog').close());$('cancelOrder').addEventListener('click',()=>$('orderDialog').close());
 $('orderForm').addEventListener('submit',e=>{e.preventDefault();const s=retailers.find(x=>x.retailer_id===shops.value),p=products.find(x=>x.product_id===pr.value),qty=Number($('newQty').value),discount=Number($('newDiscount').value);if(!s||!p||!Number.isInteger(qty)||qty<1||!Number.isFinite(discount)||discount<0||discount>50){announce('Please check your order details.');return}const command=`Retailer ${s.retailer_id} (${s.shop_name}) ke liye product ${p.product_id} (${p.product_name}) ke ${qty} pieces, ${discount}% discount ke sath quotation aur stock check karo. Abhi order book mat karna; details confirm karne ko kaho.`;$('orderDialog').close();openCommand(command,false);});}
function showChatIntro(){const f=$('chatFeed');f.replaceChildren();let block=document.createElement('div');block.className='chat-welcome';block.innerHTML='<strong>Assalamualaikum! 👋 Main Ammar AI Boss hoon.</strong><p>Sales, orders, stock, udhaar aur deliveries ke baare mein poochiye. Abhi aap sample-data demo mode mein hain; live connection settings se enable kar sakte hain.</p>';f.appendChild(block);}
function appendMessage(role,txt){const el=document.createElement('div');el.className='chat-bubble '+role;el.textContent=String(txt);$('chatFeed').appendChild(el);$('chatFeed').scrollTop=$('chatFeed').scrollHeight;return el}
function demoAnswer(text){const q=text.toLowerCase();
 const snapshotLine=`26 Oct 2026 ke fictional demo data ke mutabiq:`;
 if(/discount|offer|promotion|campaign/.test(q))return `Discount campaign draft tayyar kar sakte hain.\n\nMujhe ye confirm karein:\n• Product/category?\n• Discount kitna %?\n• Start aur end time (PKT)?\n• Kaun se opted-in retailers?\n\nDemo mode: koi email send nahi hoga. Live mode mein bhi owner approval zaroori hai.`;
 if(/email|remind|message/.test(q))return `Main approved customer list ke liye email drafts prepare kar sakta hoon.\n\nDemo mode mein real emails send nahi hote. Live n8n mein mailing ke liye verified recipients, consent aur owner approval check karna hoga.`;
 if(/price|compare|market|outside|rate/.test(q)){const c=comps[0];return `Sample comparison (NOT verified market prices):\n${c.product_name}\nDemo wholesale price: ${money(c.our_wholesale_price)}\nExample market price: ${money(c.external_price)}\nDifference: ${money(+c.external_price-+c.our_wholesale_price)}\n\nYe example prices hain, real market quote nahi. Live comparison ke liye source, date aur pack size verify karo.`}
 if(/payment|udhaar|due|pending pais|overdue|qarz|recover|balance/.test(q)){const byShop=new Map();overdue.forEach(o=>byShop.set(o.shop_name,(byShop.get(o.shop_name)||0)+ +o.balance));const list=[...byShop.entries()].sort((a,b)=>b[1]-a[1]).slice(0,5).map(([n,v],i)=>`${i+1}. ${n} — ${money(v)}`).join('\n');return `${snapshotLine}\nTotal unpaid: ${money(outstanding)}\nOverdue orders: ${overdue.length}\nTop overdue shops:\n${list||'No overdue entries'}\n\nSirf demo. Live balances n8n se verify karne honge.`}
 if(/stock|inventory|reorder|product/.test(q)){return `${snapshotLine}\nCatalog: ${products.length} products\nReorder alerts: ${stockLow.length}\n${stockLow.map(p=>`${p.product_name}: ${p.stock_qty} units left (reorder at ${p.reorder_level})`).join('\n')||'No low stock alerts'}\n\nStock numbers demo hain, warehouse mein actual stock alag ho sakta hai.`}
 if(/delivery|deliver|dispatch|rider|parcel/.test(q)){const st={PENDING:0,DISPATCHED:0,DELIVERED:0};deliveries.forEach(d=>{if(st[d.status]!==undefined)st[d.status]++});return `${snapshotLine}\nPending: ${st.PENDING}\nDispatched: ${st.DISPATCHED}\nDelivered: ${st.DELIVERED}\n\nSample pending deliveries:\n${deliveries.filter(d=>d.status==='PENDING').slice(0,4).map(d=>`${d.delivery_id} — ${d.shop_name} (${d.area})`).join('\n')}\n\nYe actual delivery tracking nahi hai.`}
 if(/book|new order|order create|order bana|quotation|quote/.test(q))return `Quotation ya order request taiyar ki ja sakti hai.\n\nRetailer ID, product ID, quantity aur approved discount dein.\n\nDemo mode mein record update nahi hoga. Live order submit karne se pehle owner se confirmation aur stock verification zaroori hai.`;
 if(/order/.test(q))return `${snapshotLine}\nTotal example orders: ${orders.length}\n26 Oct ke orders: ${salesOnDate.length}\nUn din ki invoiced amount: ${money(salesTotal)}\n\nLatest 3:\n${ordered.slice(0,3).map(o=>`${o.order_id} — ${o.shop_name} — ${money(o.total)} (${o.order_status})`).join('\n')}`;
 if(/sales|sell|sale|report|aaj|summary|business|income|profit/.test(q)){return `${snapshotLine}\nOrders: ${salesOnDate.length}\nInvoiced sales: ${money(salesTotal)}\nCollected on these orders: ${money(todayPaid)}\nAll-time sample outstanding: ${money(outstanding)}\nTotal catalog products: ${products.length}\nDelivery pending: ${deliveries.filter(d=>d.status==='PENDING').length}\n\nYeh gross invoice values hain, net profit nahi.`}
 return `Ammar Traders ke sample data se mein sales, orders, stock, deliveries, aur pending payments ka jawab de sakta hoon.\n\nTry karein: “26 Oct ko kitni sales hui?”, “Kin shops ka udhaar baqi hai?”, ya “Kon se products low stock mein hain?”\n\nKisi real business action ke liye live n8n workflow aur proper authorization ki zaroorat hai.`;
}
function unwrapReply(data){
 if(typeof data==='string'){const s=data.trim();if(!s)return '';try{return unwrapReply(JSON.parse(s))||s}catch{return s}}
 if(Array.isArray(data))return data.map(unwrapReply).filter(Boolean).join('\n');
 if(data&&typeof data==='object'){
  if(data.error)throw new Error(typeof data.error==='string'?data.error:JSON.stringify(data.error));
  for(const key of ['output','text','response','message','reply','answer','content']){if(data[key]!=null){const v=unwrapReply(data[key]);if(v)return v}}
  if(Array.isArray(data.messages))return unwrapReply(data.messages);
  if(data.data)return unwrapReply(data.data);
  return JSON.stringify(data,null,2);
 }
 return data==null?'':String(data);
}
async function askLiveBoss(text){const controller=new AbortController();const timeout=setTimeout(()=>controller.abort(),60000);try{
  const resp=await fetch(WEBHOOK_URL,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({action:'sendMessage',sessionId,chatInput:text,metadata:{source:'ammar-owner-portal',interface:'owner-dashboard'}}),signal:controller.signal,cache:'no-store',credentials:'omit'});
  if(!resp.ok)throw new Error(`Server returned HTTP ${resp.status}. Check n8n workflow activation, chat trigger and access rules.`);
  const raw=await resp.text();if(!raw.trim())throw new Error('Webhook returned an empty response. Configure the AI Agent or Respond to Webhook node to return text.');
  return unwrapReply(raw)||'The workflow returned no readable message.';
 }catch(err){if(err.name==='AbortError')throw new Error('The n8n workflow did not respond within 60 seconds. Check executions and retry.');if(err instanceof TypeError)throw new Error('Connection failed. Check n8n production webhook, Allowed Origins (CORS), HTTPS, authentication and workflow publication.');throw err;
 }finally{clearTimeout(timeout)}}
async function sendMessage(inputText){const text=String(inputText||$('chatInput').value).trim();if(!text||sending)return;if(text.length>2000){announce('Maximum 2000 characters per message.');return}navigate('boss');$('chatInput').value='';$('chatInput').style.height='auto';appendMessage('user',text);sending=true;$('sendButton').disabled=true;const indicator=document.createElement('div');indicator.className='chat-thinking';indicator.textContent=liveMode?'AI Boss is working on your request…':'Checking sample data…';$('chatFeed').appendChild(indicator);$('chatFeed').scrollTop=$('chatFeed').scrollHeight;
 try{const answer=liveMode?await askLiveBoss(text):demoAnswer(text);indicator.remove();appendMessage('bot',answer)}catch(e){indicator.remove();appendMessage('bot error',`Could not reach your AI Boss.\n${e.message}\n\nNo action has been confirmed by this website.`)}finally{sending=false;$('sendButton').disabled=false;$('chatInput').focus({preventScroll:true})}}
function openCommand(command,autoSend=false){navigate('boss');$('chatInput').value=command;autoSizeText();if(autoSend)sendMessage(command)}
function autoSizeText(){const el=$('chatInput');el.style.height='auto';el.style.height=Math.min(el.scrollHeight,130)+'px'}
function setMode(useLive){liveMode=!!useLive;$('liveSwitch').checked=liveMode;$('bossModeLabel').textContent=liveMode?'Live n8n mode':'Demo mode';$('bossModeLabel').classList.toggle('live',liveMode);$('botModeText').textContent=liveMode?'n8n AI Boss webhook':'Sample data assistant';$('settingModeDesc').textContent=liveMode?'Live requests sent to the configured n8n webhook':'Demo — uses fictional sample data';$('liveWarning').hidden=!liveMode;showChatIntro();if(liveMode)announce('Live mode selected. Only use with an authenticated owner backend.');}
function downloadCSV(){const rows=[['date','order_id','retailer','total_pkr','paid_pkr','balance_pkr','order_status'],...ordered.map(o=>[o.order_date,o.order_id,o.shop_name,o.total,o.paid,o.balance,o.order_status])];const csv=rows.map(r=>r.map(v=>'"'+String(v??'').replaceAll('"','""')+'"').join(',')).join('\r\n');const url=URL.createObjectURL(new Blob(['\ufeff'+csv],{type:'text/csv;charset=utf-8'}));const a=document.createElement('a');a.href=url;a.download='Ammar_Traders_FICTIONAL_Demo_Orders.csv';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000)}
function initialize(){
 document.querySelectorAll('[data-view]').forEach(el=>el.addEventListener('click',()=>navigate(el.dataset.view)));
 document.querySelectorAll('[data-command]').forEach(el=>el.addEventListener('click',()=>openCommand(el.dataset.command,false)));
 $('openSidebar').onclick=()=>{$('sidebar').classList.add('open');$('sidebarMask').hidden=false};$('closeSidebar').onclick=()=>{$('sidebar').classList.remove('open');$('sidebarMask').hidden=true};$('sidebarMask').onclick=()=>{$('sidebar').classList.remove('open');$('sidebarMask').hidden=true};
 $('todayDate').textContent=new Intl.DateTimeFormat('en-PK',{day:'numeric',month:'short',year:'numeric',timeZone:'Asia/Karachi'}).format(new Date());
 $('sidebarAsk').onclick=$('topAsk').onclick=()=>navigate('boss');$('dashboardReport').onclick=()=>openCommand('2026-10-26 ke daily sales aur orders ka summary report do',false);
 $('orderSearch').oninput=renderOrders;$('orderFilter').onchange=renderOrders;$('inventorySearch').oninput=renderInventory;$('inventoryFilter').onchange=renderInventory;$('paymentSearch').oninput=renderPayments;$('deliveryFilter').onchange=renderDeliveries;
 $('chatForm').addEventListener('submit',e=>{e.preventDefault();sendMessage()});$('chatInput').addEventListener('input',autoSizeText);$('chatInput').addEventListener('keydown',e=>{if(e.key==='Enter'&&!e.shiftKey){e.preventDefault();sendMessage()}});
 $('resetChat').onclick=()=>{if(sending){announce('Current request is in progress.');return}sessionId=(globalThis.crypto && crypto.randomUUID)?crypto.randomUUID():'ammar-'+Date.now();showChatIntro();announce('Started a new chat session.')};
 $('chatSuggestions').innerHTML=COMMANDS.slice(0,4).map(([name,command])=>`<button type="button" data-suggest="${esc(command)}">${esc(name)}</button>`).join('');
 $('chatSuggestions').querySelectorAll('button').forEach(b=>b.onclick=()=>openCommand(b.dataset.suggest,false));
 $('bossCommandList').innerHTML=COMMANDS.map(([name,cmd])=>`<button type="button" data-suggest="${esc(cmd)}">${icons('spark')}${esc(name)}</button>`).join('');$('bossCommandList').querySelectorAll('button').forEach(b=>b.onclick=()=>openCommand(b.dataset.suggest,false));
 $('webhookDisplay').value=WEBHOOK_URL;$('copyWebhook').onclick=async()=>{try{await navigator.clipboard.writeText(WEBHOOK_URL);announce('Webhook URL copied. Keep it private.')}catch{announce('Unable to copy automatically; select the URL instead.')}};
 $('liveSwitch').onchange=e=>{if(e.target.checked){const ok=window.confirm('SECURITY: This static site has NO user login. Its webhook URL can be seen by anyone with page access. Turn on live mode ONLY for an authenticated owner-only deployment with server-side authorization. Continue for this session?');if(!ok){e.target.checked=false;return}}setMode(e.target.checked)};
 $('testConnection').onclick=async()=>{const el=$('testResult');if(!liveMode){el.textContent='Switch to Live n8n Boss mode first. The demo assistant works locally without contacting the webhook.';return}el.textContent='Sending a read-only chat test to n8n…';try{const r=await askLiveBoss('Connectivity test only. Please reply with exactly: Ammar AI Boss connected. Do not make any changes or send emails.');el.textContent='Response received: '+r.slice(0,600)}catch(e){el.textContent='Connection error: '+e.message}};
 $('exportReport').onclick=downloadCSV;
 drawDashboard();setupStats();renderOrders();renderInventory();renderPayments();renderDeliveries();renderOffers();drawChart('reportsChart');showChatIntro();initOrderDialog();setMode(false);
}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',initialize);else initialize();
})();
