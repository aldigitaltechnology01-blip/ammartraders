# Ammar Wholesale Shop — Owner Workspace + AI Boss

Created for: **Al Digital Technology**  
Location reference: Kunri, Pakistan  
Design inspiration: Real shop photograph provided by owner (emerald storefront + red lettering).

## Kya ready hai?
- Responsive and professional personal-use owner dashboard (desktop/mobile), with real storefront photo.
- Navigation: Overview, AI Boss, Orders, Inventory, Payments, Deliveries, Offers/Email, Reports, Settings.
- 30 fictional products, 18 fictional retailers, 56 fictional orders, delivery/payment sample records. All sample statistics are anchored to 26 October 2026, NOT live balances.
- Functional filters, interactive quote/new-order draft, sample CSV export, sample date sales graph, locally computed demo assistant responses.
- **Provided n8n webhook is already in app.js**: `https://abdullahagent1.app.n8n.cloud/webhook/237e0180-34f4-4f94-bbf1-a0fa5d92d980/chat`
- Live mode switch in Settings; demo mode is ON by default to prevent accidental business actions.

## Step by step — kaise use karna hai
1. ZIP ko Extract All karo.
2. Extracted folder mein `index.html` par double-click karo. Dashboard demo browser mein open ho jayega. Sab sample-data pages offline khulenge.
3. Overview, Orders, Inventory, Payments, Deliveries check karo. AI Business Boss par `Aaj kitni sales hui?` message bhej kar offline demo answer dekh sakte ho.
4. n8n mein Boss chat webhook ka **production URL** active rakho. Ensure path wahi hai jo `app.js` mein configured hai. `action: sendMessage`, `sessionId`, `chatInput` POST payload accept hona chahiye.
5. IMPORTANT SECURITY: Live private owner Boss ko public/unprotected static website ke saath direct connect na karo! First a real owner authentication layer, protected backend/proxy with server-side authorization and appropriate CORS allow-origin. A simple PIN in JavaScript or an obscured URL does **not** protect it. The current static files offer NO owner authentication.
6. After proper security, owner-only deployment mein Settings > Use live n8n Boss enable karo (session-only setting). Confirm warning. Test Connection button *ek read-only test message bhejta hai*. Phir AI Business Boss se prompt send karo.
7. Agar CORS error aaye to n8n Chat Trigger Allowed Origins mein deployed website ka exact HTTPS origin add karo, endpoint response settings check karo, aur browser console aur n8n executions dekho. A local `file://` preview can show cross-origin issues; use a local HTTP server for testing (e.g. `python -m http.server 8000` inside extracted folder).
8. Google Sheets credentials, all employees (01-13), AI Boss toolWorkflow mappings, Gemini credential, and client authorization **must be configured inside n8n separately**. Website create karne se woh automatically connect nahi ho jate.
9. Test with fictional data. Workflows must validate all commands server-side, ask confirmation before sending emails, modifying prices, booking orders, or recording payments. No automatic email sending on the website demo.

## Upload/hosting notes
- Folder contains: `index.html`, `styles.css`, `app.js`, `demo-data.js`, `assets/ammar-shop.png`, `assets/favicon.svg` and this guide.
- For a *safe public portfolio demo*, keep DEMO MODE ON, and REMOVE/DISABLE the private AI webhook from public assets. Even if live toggle defaults OFF, the endpoint URL remains publicly viewable in app.js.
- For *real owner use*, use authenticated hosting/gateway (with session and permissions checked on server), protected API/proxy, separate read vs write tools, audit logs, backup and production database permissions. Don't rely on GitHub Pages for private access.
- `demo-data.js` is public sample-only data and must NEVER be replaced with real customers' payments or contact details on public static hosting.
- `n8n Chat Trigger`: cross-origin permissions may be required on the workflow; chat replies need to be returned as JSON (`output`/`text` etc.) or plain text. The browser client handles typical n8n reply variants but actual account connectivity cannot be guaranteed without a live test.

## Endpoint request structure

```json
{
  "action": "sendMessage",
  "sessionId": "client-generated-unique-session-id",
  "chatInput": "Aaj ki sales batao",
  "metadata": {"source":"ammar-owner-portal","interface":"owner-dashboard"}
}
```

## Important data notice
ALL sample email addresses and customer names are fictional. Competitor prices are *unverified example prices*; do not publish them as actual competitor offers. Business operations must not assume all requests succeeded. Require explicit confirmation for destructive or payment/email actions.
